# GHDL Testbench Development Tips and Best Practices (Structured, -ng)

> Dual‑purpose format: concise, machine‑friendly rules in the open text; deeper human notes and long examples inside HTML comments.

## Usage for Agents
- Ignore HTML comments (`<!-- … -->`).
- Consume only headings, **Problem/Cause/Solution**, **Pattern** snippets, and **Tags**.
- Prefer **Pattern** snippets as canonical forms when generating code.
- ⚠️ Do not edit or reorganize the main body of this file.
- If you believe you have discovered a **new tip**, append it to the footer section marked
  `------- New Tips here-------



### LOG-01: ` instead of altering the main text.
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #log #candidate-integrated



### LOG-01: VS-01: Procedure parameters must be **variables**
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #log #candidate-integrated



### VS-01: VS-02: When to use **variables** vs **signals**
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #vs #candidate-integrated



### LOG-01: DT-01: String/width alignment for reports and slices
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #log #candidate-integrated



### LOG-01: DT-02: Conversions between `std_logic_vector` and numeric types
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #log #candidate-integrated



### VS-01: DT-03: Safe concatenation patterns
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #vs #candidate-integrated



### LOG-01: LOG-01: Prefer `assert` for pass/fail, `report` for commentary
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #log #candidate-integrated



### LOG-01: LOG-02: `textio` / `writeline` canonical usage
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #log #candidate-integrated



### LOG-01: LOG-03: Human vs machine output
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #log #candidate-integrated



### GHDL-01: GHDL-01: Use VHDL‑2008 consistently
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #ghdl #candidate-integrated



### GHDL-01: GHDL-02: Compile order matters
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #ghdl #candidate-integrated



### GHDL-01: GHDL-03: Wave dumping and reproducibility
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #ghdl #candidate-integrated



### VS-01: TB-01: Clock and reset processes
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #vs #candidate-integrated



### TB-01: TB-02: Deterministic stimulus
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #tb #candidate-integrated



### VS-01: TB-03: Single-writer discipline for signals
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #vs #candidate-integrated



### LOG-01: TB-04: Boundary and fault injection checks
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #log #candidate-integrated



### TB-01: TB-05: Clock & timing management
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #tb #candidate-integrated



### LOG-01: TB-06: Reset & initialization testing
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #log #candidate-integrated



### LOG-01: Candidate: VS-03: Variable name hiding in nested scopes
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #log #candidate-integrated



### GHDL-01: Candidate: GHDL-04: Metavalue warnings in NUMERIC_STD operations
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #ghdl #candidate-integrated



### DT-01: Candidate: TB-07: Comprehensive test vector design
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #dt #candidate-integrated



### DT-01: Candidate: TB-08: System integration testing with operational mode validation
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #dt #candidate-integrated


## Appendix: Agent-Contributed Tips
Agents may append new candidate tips **below this line**.  
Do not modify the main body above.

------- New Tips here-------

