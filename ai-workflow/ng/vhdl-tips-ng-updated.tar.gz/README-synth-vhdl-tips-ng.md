# Synthesizable VHDL Tips and Best Practices (Structured, -ng)

> Dual-purpose format: concise, machine-friendly rules in the open text; deeper human notes and long examples inside HTML comments.

## Usage for Agents
- Ignore HTML comments (`<!-- … -->`).
- Consume only headings, **Problem/Cause/Solution**, **Pattern** snippets, and **Tags**.
- Prefer **Pattern** snippets as canonical forms when generating code.
- ⚠️ Do not edit or reorganize the main body of this file.
- If you believe you have discovered a **new tip**, append it to the footer section marked
  `------- New Tips here-------



### PROC-01: ` instead of altering the main text.
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #proc #candidate-integrated



### PROC-01: PROC-01: Avoid unintended latches
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #proc #candidate-integrated



### PROC-01: SIG-01: Single-writer for signals
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #proc #candidate-integrated



### SIG-01: SIG-02: Prefer **named association** & explicit conversions
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #sig #candidate-integrated



### PROC-01: SIG-03: Define **signal priority** & truth table
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #proc #candidate-integrated



### PROC-01: TIM-01: Constrain critical paths
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #proc #candidate-integrated



### PROC-01: RES-01: BRAM inference patterns
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #proc #candidate-integrated



### PROC-01: STD-01: Use portable subset for Verilog
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #proc #candidate-integrated



### PROC-01: Candidate: PROC-02: Function declarations in architectures
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #proc #candidate-integrated



### PROC-01: Candidate: TIM-02: Pipeline registers for complex calculations
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #proc #candidate-integrated



### PROC-01: Candidate: SIG-04: Comprehensive status reporting in top-level modules
**Problem**: …  
**Cause**: …  
**Solution**: …  
**Pattern**:
```vhdl
-- example
```
**Tags**: #proc #candidate-integrated


## Appendix: Agent-Contributed Tips
Agents may append new candidate tips **below this line**.  
Do not modify the main body above.

------- New Tips here-------

